import zlib

with open("InflatedM.save", "rb") as file:
    inflated_buffer = file.read()

zipped_buffer = zlib.compress(inflated_buffer)

with open("FixMaintain.save", "wb") as file:
    file.write(zipped_buffer)
    
pass
    
    