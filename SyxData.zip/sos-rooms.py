from zipfile import ZipFile
import json
import re

debug = False

# function used to check if a file is in the tech directory
# Also, remove _EXAMPLE and _BOOSTABLES
def isRoom(filename):
    if filename.startswith("data/assets/init/room/") and filename.endswith(".txt"):
        return True
    else:
        return False

def remove_comments(text: str):
    lines = []
    for line in text.split('\n'):
        if not '**' in line:
            lines.append(line)
    out_text = ''
    for line in lines:
        out_text += line
    return out_text

def tokenize(text: str):
    tokens = []
    token = ""
    for c in text:
        if c == ':' or c == ',' or c == '[' or c==']' or c =='{' or c=='}' or c.isspace():
            if token:
                if not token.startswith('\"'):      # Quote if not quoted
                    token = '"' + str(token) + '"'
                tokens.append(str(token))           # Add to list
                token = ""
            if not c.isspace():
                tokens.append(c)
        else:
            token += c
    if token:
        tokens.append(token)
    return tokens
        


def fix_spaces(text: str):
    text = text.replace('\r', ' ')
    text = text.replace('\t', ' ')
    text = text.replace(',', '')
    return text

def isnumber(text):
    if text.isnumeric(): return True
    if text.count('.') == 1: return True
    return False

def iskey(text):
    return text[-1:] == ":"

def istext(text):
    return text[-1:].isalpha()

def ispunct(text):
    if isnumber(text) or iskey(text) or istext(text): return False
    return True 

def redecorate(text: str):
    text = '{' + text + '}'
    text = remove_comments(text)
    tokens = tokenize(text)
    remove_commas_before_braces(tokens)
    fix_objects_in_brackets(tokens)
    output = ''
    for token in tokens:
        output += token + '\n'
    return output    

def remove_commas_before_braces(tokens):
    n = 0
    while n < len(tokens):
        if (tokens[n] == ']' or tokens[n]== '}') and tokens[n-1] == ',':
            tokens.pop(n-1)
        n+=1
        
def is_naked_in_list(tokens, loc):
    p = loc-1 
    curly_count = 0
    while p >= 0:
        if tokens[p] == '{':
            curly_count += 1
        elif tokens[p] == '}':
            curly_count -= 1
        elif tokens[p] == '[':
            if curly_count == 0:
                return True
            return False
        elif tokens[p] == ']':
            return False
        p -= 1
    return False
            

def fix_objects_in_brackets(tokens):
    l = 2
    while l < len(tokens) - 2:
        if tokens[l] == ':' and is_naked_in_list(tokens, l):
            tokens.insert(l+2, '}')
            tokens.insert(l-1, '{')
        l+=1

      
def make_csv(industries):
    f = open("industry.csv", 'w')
    f.write('name,in_type_1,in_qty_1,in_type_2,in_qty_2,out_type_1,out_qty_1,out_type_2,out_qty_2\n')
    for industry in industries:
        csv_string = f"{industry['NAME']}"
        if 'IN' in industry:
            for input in industry['IN']:
                csv_string += ',' + input + ',' + industry['IN'][input]
        while csv_string.count(',') < 4:
            csv_string += ','

        if 'OUT' in industry:
            for output in industry['OUT']:
                csv_string += ',' + output + ',' + industry['OUT'][output]
        while csv_string.count(',') < 8:
            csv_string += ','
        f.write(csv_string)
        f.write("\n")
    f.close()

# name of the zip file with the data
file_name = "F:/GOG/Songs of Syx/base/data.zip"
# open up the zip file with the data and get a list of files inide
with ZipFile(file_name, 'r') as zip:
    name_list = zip.namelist()
    # Winnow list to just techs
    name_list = filter(isRoom, name_list)
    # Go through each file and put the rooms into a single array
    rooms = []
    for filename in name_list:
        contents = zip.read(filename).decode()
        if not contents: continue
        fixed = redecorate(contents)
        room = json.loads(fixed)
        name = filename.split('/')[-1][0:-4]
        if name.startswith('_'): name = name[1:]
        room['NAME'] = name
        rooms.append(room)
        
    industries = []
    for room in rooms:
        if "INDUSTRIES" in room:
            for industry in room['INDUSTRIES']:
                industry = industry['INDUSTRY']
                industry['NAME'] = room['NAME']
                industries.append(industry)
        if "INDUSTRY" in room:
            industry = room['INDUSTRY']
            industry['NAME'] = room['NAME']
            industries.append(industry)
        if 'MINABLE' in room:
            industry = {
                    'NAME': room['NAME'],
                    'OUT': {
                            room['MINABLE']: room['YEILD_WORKER_DAILY']
                    }
            }
            industries.append(industry)
    make_csv(industries)



            


