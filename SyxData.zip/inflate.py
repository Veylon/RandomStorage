import zlib

with open("HardMaintain.save", "rb") as file:
    zipped_buffer = file.read()
    
inflated_buffer = zlib.decompress(zipped_buffer)

with open("InflatedM.save", "wb") as file:
    file.write(inflated_buffer)

pass
    
    