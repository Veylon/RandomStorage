from zipfile import ZipFile
import json
import re

debug = False


def techcost(tech):
    if tech['LEVEL_MAX'] > 1:
        total = 0
        for l in range(tech['LEVEL_MAX']):
            total += tech['LEVEL_COST'] * (tech['LEVEL_COST_INC_MUL'] ** l)
        return total
    return tech['LEVEL_COST']

# Split the line into parts
# First by quotes, then by colons (there shouldn't be any text with colons in it)
def getparts(rawline):
    stringparts = rawline.split('\"')
    outparts = []
    for rawstringpart in stringparts:
        colonparts = rawstringpart.split(':')
        for rawcolonpart in colonparts:
            cleanline = rawcolonpart.replace('\t','')
            cleanline = rawcolonpart.replace(',','')
            cleanline = cleanline.strip()
            if len(cleanline):
                outparts.append(cleanline)
    return outparts

# Search the contents of the file for the first KEY: VALUE pair
# matching the description
def searchContentsFor(contents, identifier):
    lines = contents.splitlines()
    for rawline in lines:
        parts = getparts(rawline)
        if len(parts) != 2: continue
        if parts[0] == identifier:
            return parts[1].replace("\"",'')
    return None

# Get the name of the item by looking in the equivalent text file
# and then searching for NAME
def get_name(zip, filename):
    filename = filename.replace("init", "text")
    contents = zip.read(filename).decode()
    name = searchContentsFor(contents, "NAME")
    if name is None:
        return filename.split('/')[-1].replace('.txt','')
    else:
        return name
    
# Get all the files in the zip matching all of the filters input
# filters is either a single string or a list of strings
def getFiles(zip, filters):
    allfiles = zip.namelist()
    files = []
    for file in allfiles:
        match = True
        for filter in filters:
            match = filter in file
        if match:
            files.append(file)
    return files
    
def createCSV(zip, filters, filename, *fields):
    with open(f"{filename}.csv", "w") as csv:
        csv.write('name,')
        for field in fields:
            csv.write(f'{field}')
            if field != fields[-1]:
                csv.write(',')
        csv.write('\n')
        files = getFiles(zip, filters)
        for file in files:
            contents = zip.read(file).decode()
            if not contents: continue
            name = get_name(zip, file)
            csv.write(f'{name},')
            for field in fields:
                value = searchContentsFor(contents, field)
                if value:
                    csv.write(f'{value}')
                if field == fields[-1]:
                    csv.write(f'\n')
                else:
                    csv.write(f',')

def getnextpair(contents, index):
    pass
                    
def createIndustries(zip):
    with open("industries.csv", "w") as csv:
        csv.write("name,out,out rate,in1,in1 rate,in2,in2 rate,in3,in3 rate\n")
        files = getFiles(zip, ["data/assets/init/room/"])
        for file in files:
            contents = zip.read(file).decode()
            if not contents: continue
            industries = []
            mineable = searchContentsFor(contents, "MINABLE")
            worker_yield = searchContentsFor(contents, "YEILD_WORKER_DAILY")
            if mineable and worker_yield:
                industries.append({"out": mineable, "rate": worker_yield})
            next_is_out = False
            for rawline in contents.splitlines():
                line = rawline.strip()
                industries.append({"out": mineable, "rate": worker_yield})
                next_is_out = "OUT" in line
                pass
            
            
    
# name of the zip file with the data
file_name = "F:/GOG/Songs of Syx/base/data.zip"
# open up the zip file with the data and get a list of files inide
with ZipFile(file_name, 'r') as zip:
 #   createCSV(zip, ["data/assets/init/tech/", "nodes"], "techs", "LEVEL_MAX", "LEVEL_COST", "LEVEL_COST_INC_MUL")
 #   createCSV(zip, []"data/assets/init/room/"], "rooms", "NEED", "RADIUS")
    createIndustries(zip)




            


