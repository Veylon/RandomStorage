from zipfile import ZipFile
import json
import re

debug = False

# function used to check if a file is in the tech directory
# Also, remove _EXAMPLE and _BOOSTABLES
def isTech(filename):
    if filename.startswith("data/assets/init/tech/") and not filename.startswith("data/assets/init/tech/_"):
        return True
    else:
        return False

def remove_comments(text: str):
    lines = []
    for line in text.split('\n'):
        if not '**' in line:
            lines.append(line)
    out_text = ''
    for line in lines:
        out_text += line
    return out_text

def tokenize(text: str):
    tokens = []
    for token in text.split(' '):
        if token:
            tokens.append(token)
    return tokens

def fix_spaces(text: str):
    text = text.replace('\r', ' ')
    text = text.replace('\t', ' ')
    text = text.replace(',', '')
    return text

def isnumber(text):
    if text.isnumeric(): return True
    if text.count('.') == 1: return True
    return False

def iskey(text):
    return text[-1:] == ":"

def istext(text):
    return text[-1:].isalpha()

def ispunct(text):
    if isnumber(text) or iskey(text) or istext(text): return False
    return True 

def redecorate(text: str):
    clean_text = remove_comments(text)
    clean_text = fix_spaces(clean_text)
    tokens = tokenize(clean_text)
    output = ''
    for pos in range(len(tokens)):
        token = tokens[pos]
        if token == "TECHS:": continue
        if iskey(token):
            token = '\"' + token[0:-1] + '\":'
        else:
            if istext(token) or (pos > 0 and tokens[pos-1] == "TREE_ORDER:"):
                token = '\"' + token + '\"'
            if not pos == len(tokens)-1 and not token == '[' and not token == '{' and (tokens[pos+1] == '{' or iskey(tokens[pos+1]) or istext(tokens[pos+1])):
                token += ','
        output += token + '\n'
    return output

def describe_bonus(tech):
    output = ''
    if 'ROOMS' in tech:
        for room in tech['ROOMS']:
            if output: output += ', '
            output += room
    if 'INDUSTRIES' in tech:
        if output: output += ', '
        for item in tech['INDUSTRIES'].items():
            if output: output += ', '
            output += f"{item[0]}: {item[1]}"
    if 'BONUS_ADD' in tech:
        for item in tech['BONUS_ADD'].items():
            for bonus in item[1].items():
                if output: output += ', '
                output += f"{bonus[0]}: {bonus[1]}"
    if 'UPGRADES' in tech:
        output += 'UPGRADES: ['
        for upgrade in tech['UPGRADES']:
            output += upgrade + ", "
        if len(tech['UPGRADES']):
            output = output[:-2] # Erase last comma
        output += ']'
    if 'FLOORS' in tech:
        for floor in tech['FLOORS']:
            if output: output += ', '
            output += floor
    if not output:
        pass
    return output

def techcost(tech):
    if 'LEVEL_MAX' in tech:
        total = 0
        for l in range(tech['LEVEL_MAX']):
            total += tech['LEVEL_COST'] * (tech['LEVEL_COST_INC_MUL'] ** l)
        return total
    return tech['LEVEL_COST']

def showcost(tech, total_cost):
    percent = int(10000 * techcost(tech) / total_cost) # This formats it to be xx.xx%
    percent = percent / 100
    if(techcost(tech) >= 1000000):
        print(f'{describe_bonus(tech)}: {(int(techcost(tech) / 100000) * 100000) / 1000000}M', end='')
    elif(techcost(tech) >= 1000):
        print(f'{describe_bonus(tech)}: {(int(techcost(tech) / 100) * 100) / 1000}k', end='')
    else:
        print(f'{describe_bonus(tech)}: {techcost(tech)}', end='')
    if percent > 0:
        print(f" {percent}%")
    else:
        print('')
        
def make_csv(techs):
    f = open("techs.csv", 'w')
    f.write('name,first_level,num_levels,increment,cost\n')
    for tech in techs:
        name = describe_bonus(tech)
        name = name.replace(',', '')
        first_level = tech['LEVEL_COST']
        num_levels = 1
        increment = 1
        cost = techcost(tech)
        if 'LEVEL_MAX' in tech:
            num_levels = tech['LEVEL_MAX']
            increment =  tech['LEVEL_COST_INC_MUL']
        f.write(f'{name},{first_level},{num_levels},{increment},{cost}\n')
    f.close()

# name of the zip file with the data
file_name = "F:/GOG/Songs of Syx/base/data.zip"
# open up the zip file with the data and get a list of files inide
with ZipFile(file_name, 'r') as zip:
    name_list = zip.namelist()
    # Winnow list to just techs
    name_list = filter(isTech, name_list)
    # Total Cost of all techs
    grand_total = 0
    known_total = 57870331
    # Go through each file and put the techs into a single array
    alltechs = []
    for filename in name_list:
        contents = zip.read(filename).decode()
        if not contents: continue
        fixed = redecorate(contents)
        techlist = json.loads(fixed)
        for tech in techlist:
            alltechs.append(tech)
    # Get the total cost of all techs
    total_cost = 0
    for tech in alltechs:
        total_cost += techcost(tech)
    # Sort by cost
    alltechs.sort(key = techcost)
    # Display the techs
    for tech in alltechs:
        showcost(tech, total_cost)
        if 'LEVEL_MAX' in tech:
            print(" Max:", tech['LEVEL_MAX'], " Inc:", tech['LEVEL_COST_INC_MUL'])
    make_csv(alltechs)



            


